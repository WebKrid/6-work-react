import React from "react";

const Users = ({user, id}) => {
   return (
      <div key={id}>
         <div>{user.name}</div>
         <div><button>Удалить  пользователя</button></div>
      </div>
   )
}