const initiaState = {
   users: [
      {
         id: 1,
         name: 'alexseya'
      },
      {
         id: 2,
         name: 'Vasilyya'
      },
      {
         id: 3,
         name: 'margo'
      },
      {
         id: 4,
         name: 'Bogdan'
      },
   ]
}

export const reducer = (state = initiaState, action) => {
   switch (action.type) {
   case 'deleteUser':
      return {
         ...state, 
         users: state.users.filter((user)) 
      }
      case 'addUser':
         return {
            ...state,
            users: [...state.users, action.payload]
         }
      default: 
         return state
   }
}