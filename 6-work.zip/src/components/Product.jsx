import {useParams} from "react-router-dom";
import {useSelector} from "react-redux";

const Product = () => {
   const { id } = useParams();
   const categoryProducts = useSelector( state => state.products)

   const products = categoryProducts.filter((products) => {

      return product.categoryId === Number(id)
   })

   return (
      <div>
         {products.map((item) => (
            <div key={item.id}>
             <div>
               {item.name}
             </div>
            </div>
         ))}
      </div>
   );
};
