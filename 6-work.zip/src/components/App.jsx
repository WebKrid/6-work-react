import {createStore} from "redux";
import { reducer } from "./reducers/reducer";
import {composeWithDevTools} from "redux-devtools-extension";
import { Route } from "react-router-dom";
import Categories from "./Categories";

function App() {


   return (
      <Routes>
         <Route path='/' element={<Categories />}/>
         <Route path={'/product/:id'} element={<Product/>} />
      </Routes>
   );
}


  

export default App;
