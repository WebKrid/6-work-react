import React from 'react';
import {useDispatch, useSelector} from "react-redux";
import {NavLink} from "react-router-dom";

const Categories = () => {
   const categories = useSelector( state => state.categories)
   return(
      <div>
         {categories.map((category) => (
         <NavLink to={`/product/${category.id}`} >
           {category.name}
         </NavLink>
         ))}

      </div>
   )
};

export default Categories;